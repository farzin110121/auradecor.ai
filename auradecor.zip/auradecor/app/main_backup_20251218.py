from fastapi import FastAPI, Form
from fastapi.responses import HTMLResponse
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
import cv2
import numpy as np
from ultralytics import YOLO
import easyocr
import uvicorn
import os

app = FastAPI(title="AURADECOR.ai - AI Interior Design Studio")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# سرو فایل‌های استاتیک (برای تصویر پس‌زمینه و …)
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
app.mount("/static", StaticFiles(directory=os.path.join(BASE_DIR, "static")), name="static")

# ------------------ SCHEMAS مغز AURADECOR ------------------ #

class Room(BaseModel):
    id: str
    type: Literal["living_room", "kitchen", "bedroom", "bathroom", "hall", "balcony", "office", "other"]
    name: str
    area_m2: Optional[float] = None
    bbox: Optional[tuple[int, int, int, int]] = None  # x1, y1, x2, y2

class FloorplanAnalysis(BaseModel):
    project_id: str
    total_area_m2: float
    rooms: List[Room]
    connections: List[tuple[str, str]]  # ("living_1", "kitchen_1")

class RoomDesign(BaseModel):
    room_id: str
    style: str
    description: str
    materials: List[str]
    furniture: List[str]
    image_urls: List[str]

class ProjectDesign(BaseModel):
    project_id: str
    style: str
    total_cost_estimate: float
    rooms: List[RoomDesign]
    notes: str


# ------------------ صفحه اصلی (Landing) ------------------ #

@app.get("/", response_class=HTMLResponse)
async def home():
    return HTMLResponse(content="""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AURADECOR.ai - Transform Floor Plans to Luxury Interiors</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            font-family: 'Inter', sans-serif; 
            background: 
                linear-gradient(180deg, rgba(0,0,0,0.80), rgba(0,0,0,0.95)),
                url("/static/images/hero-design.jpg") center center / cover no-repeat fixed;
            color: #ffffff; 
            overflow-x: hidden;
            line-height: 1.6;
        }
        .container { max-width: 1400px; margin: 0 auto; padding: 0 20px; }
        
        /* Header */
        header { 
            position: fixed; 
            top: 0; left: 0; right: 0; 
            background: rgba(10,10,10,0.95); 
            backdrop-filter: blur(20px); 
            z-index: 1000; 
            padding: 15px 0; 
            border-bottom: 1px solid #333;
        }
        nav { display: flex; justify-content: space-between; align-items: center; }
        .logo { 
            font-family: 'Playfair Display', serif; 
            font-size: 28px; 
            font-weight: 700; 
            background: linear-gradient(135deg, #D4AF37, #F1C40F); 
            -webkit-background-clip: text; 
            -webkit-text-fill-color: transparent; 
            background-clip: text;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .logo-icon { 
            width: 40px; height: 40px; 
            background: linear-gradient(135deg, #D4AF37, #F1C40F); 
            border-radius: 50%; 
            display: flex; align-items: center; justify-content: center; 
            font-size: 18px;
            box-shadow: 0 0 30px rgba(212, 175, 55, 0.5);
        }
        .auth-buttons { display: flex; gap: 15px; }
        .btn { 
            padding: 12px 28px; 
            border-radius: 25px; 
            text-decoration: none; 
            font-weight: 500; 
            transition: all 0.3s; 
            border: 2px solid transparent; 
            font-size: 14px;
        }
        .btn-primary { 
            background: linear-gradient(135deg, #D4AF37, #F1C40F); 
            color: #000; 
        }
        .btn-secondary { color: #D4AF37; border-color: #D4AF37; }
        .btn-primary:hover, .btn-secondary:hover { 
            transform: translateY(-2px); 
            box-shadow: 0 10px 30px rgba(212, 175, 55, 0.4); 
        }
        
        /* Hero Section */
        .hero { 
            min-height: 100vh; 
            display: flex; 
            align-items: center; 
            text-align: center; 
            background: radial-gradient(ellipse at center, rgba(212,175,55,0.1) 0%, transparent 70%);
            padding-top: 100px;
        }
        .hero h1 { 
            font-family: 'Playfair Display', serif; 
            font-size: clamp(3rem, 8vw, 6rem); 
            background: linear-gradient(135deg, #D4AF37, #F1C40F, #D4AF37); 
            -webkit-background-clip: text; 
            -webkit-text-fill-color: transparent; 
            background-clip: text;
            margin-bottom: 20px;
            animation: glow 2s ease-in-out infinite alternate;
        }
        @keyframes glow {
            from { filter: drop-shadow(0 0 20px rgba(212,175,55,0.5)); }
            to { filter: drop-shadow(0 0 30px rgba(212,175,55,0.8)); }
        }
        .hero-subtitle { 
            font-size: clamp(1.2rem, 3vw, 1.8rem); 
            color: #ccc; 
            max-width: 600px; 
            margin: 0 auto 40px;
        }
        .hero-buttons { display: flex; gap: 20px; justify-content: center; flex-wrap: wrap; }
        .btn-hero { 
            padding: 20px 50px; 
            font-size: 1.2rem; 
            font-weight: 600; 
            border-radius: 50px; 
        }
        
        /* Features */
        .features { padding: 120px 0; }
        .features-title { 
            text-align: center; 
            font-family: 'Playfair Display', serif; 
            font-size: 3rem; 
            color: #D4AF37; 
            margin-bottom: 80px;
        }
        .features-grid { 
            display: grid; 
            grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); 
            gap: 40px; 
        }
        .feature-card { 
            background: linear-gradient(145deg, rgba(255,255,255,0.03), rgba(255,255,255,0.01)); 
            border: 1px solid rgba(212,175,55,0.2); 
            border-radius: 24px; 
            padding: 40px 30px; 
            text-align: center; 
            transition: all 0.4s; 
            backdrop-filter: blur(20px);
            position: relative; overflow: hidden;
        }
        .feature-card::before {
            content: ''; position: absolute; top: 0; left: -100%; width: 100%; height: 100%; 
            background: linear-gradient(90deg, transparent, rgba(212,175,55,0.1), transparent); 
            transition: 0.7s;
        }
        .feature-card:hover::before { left: 100%; }
        .feature-card:hover { 
            transform: translateY(-15px); 
            border-color: #D4AF37; 
            box-shadow: 0 30px 60px rgba(212,175,55,0.25);
        }
        .feature-icon { 
            width: 80px; height: 80px; 
            background: linear-gradient(135deg, #D4AF37, #F1C40F); 
            border-radius: 20px; 
            display: flex; align-items: center; justify-content: center; 
            margin: 0 auto 25px; 
            font-size: 2rem; 
            box-shadow: 0 10px 30px rgba(212,175,55,0.4);
        }
        .feature-title { font-size: 1.5rem; font-weight: 600; color: #D4AF37; margin-bottom: 15px; }
        .feature-desc { color: #aaa; line-height: 1.7; }
        
        /* Responsive */
        @media (max-width: 768px) { 
            .hero-buttons { flex-direction: column; align-items: center; }
            .btn-hero { width: 100%; max-width: 300px; }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <header>
        <nav class="container">
            <div class="logo">
                <span class="logo-icon">🧠</span>
                AURADECOR.ai
            </div>
            <div class="auth-buttons">
                <a href="/login" class="btn btn-secondary">Sign In</a>
                <a href="/register" class="btn btn-primary">Get Started</a>
            </div>
        </nav>
    </header>

    <!-- Hero -->
    <section class="hero">
        <div class="container">
            <h1>AI-Powered Interior Design</h1>
            <p class="hero-subtitle">
                Transform any floor plan into stunning, personalized interiors in minutes. 
                No design skills required – just upload and create.
            </p>
            <div class="hero-buttons">
                <a href="/register/owner" class="btn btn-hero btn-primary">
                    <i class="fas fa-home"></i> Start as Homeowner
                </a>
                <a href="/register/contractor" class="btn btn-hero btn-secondary">
                    <i class="fas fa-hammer"></i> Join as Contractor
                </a>
            </div>
        </div>
    </section>

    <!-- Features -->
    <section class="features">
        <div class="container">
            <h2 class="features-title">Why Choose AURADECOR?</h2>
            <div class="features-grid">
                <div class="feature-card">
                    <div class="feature-icon"><i class="fas fa-brain"></i></div>
                    <h3 class="feature-title">95% Accurate Plan Recognition</h3>
                    <p class="feature-desc">Upload any floor plan – our AI instantly detects rooms, measurements, and layouts with precision.</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon"><i class="fas fa-comments"></i></div>
                    <h3 class="feature-title">Real-time AI Chat Editor</h3>
                    <p class="feature-desc">"Make it modern", "Add gold accents" – chat with AI and watch your design transform instantly.</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon"><i class="fas fa-globe"></i></div>
                    <h3 class="feature-title">Global USDT Payments</h3>
                    <p class="feature-desc">Pay with crypto from anywhere. No banks, no borders, instant subscriptions worldwide.</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon"><i class="fab fa-whatsapp"></i></div>
                    <h3 class="feature-title">Direct Contractor Connect</h3>
                    <p class="feature-desc">One-click WhatsApp connection to verified contractors. From design to execution seamlessly.</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon"><i class="fas fa-download"></i></div>
                    <h3 class="feature-title">Professional 4K Downloads</h3>
                    <p class="feature-desc">Download photorealistic 2D/3D renders + material lists + contractor-ready plans.</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon"><i class="fas fa-crown"></i></div>
                    <h3 class="feature-title">Unlimited Designs</h3>
                    <p class="feature-desc">$19/month for unlimited floor plans, styles, and revisions. First design FREE.</p>
                </div>
            </div>
        </div>
    </section>
</body>
</html>
    """)


# ------------------ داشبورد مالک ------------------ #

@app.get("/register/owner", response_class=HTMLResponse)
async def owner_dashboard():
    return HTMLResponse(content="""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Owner Dashboard | AURADECOR.ai</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        * { margin:0; padding:0; box-sizing:border-box; }
        body {
            font-family:'Inter',sans-serif;
            background:#050505;
            color:#fff;
        }
        .topbar {
            display:flex;
            align-items:center;
            justify-content:space-between;
            padding:16px 32px;
            border-bottom:1px solid #333;
            background:rgba(5,5,5,0.96);
            position:sticky;
            top:0;
            z-index:10;
        }
        .brand {
            font-weight:600;
            color:#D4AF37;
        }
        .user {
            font-size:14px;
            color:#aaa;
        }
        .layout {
            display:grid;
            grid-template-columns:260px 1fr;
            min-height:100vh;
        }
        .sidebar {
            border-right:1px solid #222;
            padding:24px 18px;
            background:#070707;
        }
        .sidebar h2 {
            font-size:14px;
            color:#777;
            margin-bottom:16px;
        }
        .nav-item {
            padding:10px 12px;
            border-radius:10px;
            font-size:14px;
            color:#ccc;
            cursor:pointer;
            margin-bottom:6px;
        }
        .nav-item.active {
            background:linear-gradient(135deg,#D4AF37,#F1C40F);
            color:#000;
            font-weight:600;
        }
        .nav-item:hover {
            background:rgba(255,255,255,0.05);
        }
        .content {
            padding:28px 32px 40px;
        }
        .section-title {
            font-size:22px;
            margin-bottom:8px;
        }
        .section-sub {
            font-size:14px;
            color:#aaa;
            margin-bottom:24px;
        }
        .card-row {
            display:grid;
            grid-template-columns:2fr 1.3fr;
            gap:24px;
            margin-bottom:32px;
        }
        .card {
            background:rgba(255,255,255,0.03);
            border-radius:20px;
            border:1px solid rgba(212,175,55,0.20);
            padding:20px 18px;
        }
        .card h3 {
            font-size:16px;
            margin-bottom:10px;
            color:#D4AF37;
        }
        .card p {
            font-size:13px;
            color:#aaa;
            margin-bottom:14px;
        }
        .upload-box {
            border:1px dashed rgba(212,175,55,0.5);
            border-radius:16px;
            padding:18px;
            text-align:center;
            background:rgba(0,0,0,0.5);
        }
        .upload-box input[type=file] {
            margin-top:12px;
            color:#ccc;
        }
        .btn {
            display:inline-block;
            padding:10px 20px;
            border-radius:999px;
            border:none;
            background:linear-gradient(135deg,#D4AF37,#F1C40F);
            color:#000;
            font-weight:600;
            font-size:14px;
            cursor:pointer;
            margin-top:10px;
        }
        .btn:hover {
            box-shadow:0 12px 30px rgba(212,175,55,0.4);
            transform:translateY(-1px);
        }
        .projects-list {
            margin-top:10px;
        }
        .project-item {
            padding:10px 0;
            border-bottom:1px solid #222;
            font-size:13px;
            display:flex;
            justify-content:space-between;
            align-items:center;
        }
        .badge {
            padding:3px 9px;
            border-radius:999px;
            font-size:11px;
        }
        .badge-processing {
            background:#333;
            color:#F1C40F;
        }
        .badge-ready {
            background:#16361a;
            color:#2ecc71;
        }
    </style>
</head>
<body>
    <div class="topbar">
        <div class="brand">AURADECOR.ai · Owner</div>
        <div class="user">You are logged in as <span style="color:#D4AF37;">Homeowner</span></div>
    </div>

    <div class="layout">
        <aside class="sidebar">
            <h2>Navigation</h2>
            <div class="nav-item active">Dashboard</div>
            <a href="/owner/projects" style="text-decoration:none;">
                <div class="nav-item">My Projects</div>
            </a>
            <div class="nav-item">Downloads</div>
            <div class="nav-item">Subscription</div>
            <div class="nav-item">Account Settings</div>
        </aside>

        <main class="content">
            <h1 class="section-title">Welcome to your design studio</h1>
            <p class="section-sub">Upload a floor plan, choose a style and let AURADECOR.ai generate stunning interiors for you.</p>

            <div class="card-row">
                <div class="card">
                    <h3>Start a new project</h3>
                    <p>Upload your floor plan and select your preferred style. We’ll generate multiple AI-powered designs for you.</p>
                    <div class="upload-box">
                        <p style="font-size:13px;">Drop your floor plan file here, or click to select.</p>
                        <input type="file" name="floorplan" accept="image/*,.pdf">
                        <div style="margin-top:12px;">
                            <select name="style" style="padding:8px 10px;border-radius:999px;border:1px solid #555;background:#000;color:#fff;font-size:13px;">
                                <option value="modern">Modern</option>
                                <option value="luxury">Luxury</option>
                                <option value="minimal">Minimal</option>
                                <option value="classic">Classic</option>
                                <option value="industrial">Industrial</option>
                            </select>
                        </div>
                        <button class="btn" type="button">Generate Design (mock)</button>
                    </div>
                </div>

                <div class="card">
                    <h3>Subscription status</h3>
                    <p>Your free trial is active. You can generate 1 design for free before subscribing.</p>
                    <p style="font-size:13px;color:#ddd;">
                        Upgrade to unlock unlimited projects and priority AI rendering.
                    </p>
                    <button class="btn" type="button" onclick="alert('Subscription flow will be implemented later.')">
                        View plans
                    </button>
                </div>
            </div>

            <div class="card">
                <h3>Your recent projects</h3>
                <div class="projects-list">
                    <div class="project-item">
                        <span>Modern Apartment · Living + Kitchen</span>
                        <span class="badge badge-processing">processing (mock)</span>
                    </div>
                    <div class="project-item">
                        <span>Luxury Villa · Master Bedroom</span>
                        <span class="badge badge-ready">ready (mock)</span>
                    </div>
                </div>
            </div>
        </main>
    </div>
</body>
</html>
    """)


# ------------------ داشبورد تأمین‌کننده ------------------ #

@app.get("/register/contractor", response_class=HTMLResponse)
async def contractor_dashboard():
    return HTMLResponse(content="""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Contractor Dashboard | AURADECOR.ai</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        * { margin:0; padding:0; box-sizing:border-box; }
        body {
            font-family:'Inter',sans-serif;
            background:#050505;
            color:#fff;
        }
        .topbar {
            display:flex;
            align-items:center;
            justify-content:space-between;
            padding:16px 32px;
            border-bottom:1px solid #333;
            background:rgba(5,5,5,0.96);
            position:sticky;
            top:0;
            z-index:10;
        }
        .brand {
            font-weight:600;
            color:#D4AF37;
        }
        .user {
            font-size:14px;
            color:#aaa;
        }
        .layout {
            display:grid;
            grid-template-columns:260px 1fr;
            min-height:100vh;
        }
        .sidebar {
            border-right:1px solid #222;
            padding:24px 18px;
            background:#070707;
        }
        .sidebar h2 {
            font-size:14px;
            color:#777;
            margin-bottom:16px;
        }
        .nav-item {
            padding:10px 12px;
            border-radius:10px;
            font-size:14px;
            color:#ccc;
            cursor:pointer;
            margin-bottom:6px;
        }
        .nav-item.active {
            background:linear-gradient(135deg,#D4AF37,#F1C40F);
            color:#000;
            font-weight:600;
        }
        .nav-item:hover {
            background:rgba(255,255,255,0.05);
        }
        .content {
            padding:28px 32px 40px;
        }
        .section-title {
            font-size:22px;
            margin-bottom:8px;
        }
        .section-sub {
            font-size:14px;
            color:#aaa;
            margin-bottom:24px;
        }
        .card-row {
            display:grid;
            grid-template-columns:1.5fr 1.2fr;
            gap:24px;
            margin-bottom:32px;
        }
        .card {
            background:rgba(255,255,255,0.03);
            border-radius:20px;
            border:1px solid rgba(212,175,55,0.20);
            padding:20px 18px;
        }
        .card h3 {
            font-size:16px;
            margin-bottom:10px;
            color:#D4AF37;
        }
        .card p {
            font-size:13px;
            color:#aaa;
            margin-bottom:14px;
        }
        .field {
            margin-bottom:14px;
        }
        .field label {
            display:block;
            font-size:13px;
            margin-bottom:6px;
            color:#ddd;
        }
        .field input, .field textarea, .field select {
            width:100%;
            padding:10px 12px;
            border-radius:12px;
            border:1px solid #444;
            background:#000;
            color:#fff;
            font-size:13px;
        }
        .field textarea {
            min-height:70px;
            resize:vertical;
        }
        .hint {
            font-size:11px;
            color:#777;
            margin-top:2px;
        }
        .btn {
            display:inline-block;
            padding:10px 20px;
            border-radius:999px;
            border:none;
            background:linear-gradient(135deg,#D4AF37,#F1C40F);
            color:#000;
            font-weight:600;
            font-size:14px;
            cursor:pointer;
            margin-top:8px;
        }
        .btn:hover {
            box-shadow:0 12px 30px rgba(212,175,55,0.4);
            transform:translateY(-1px);
        }
        .lead-list {
            margin-top:10px;
        }
        .lead-item {
            padding:10px 0;
            border-bottom:1px solid #222;
            font-size:13px;
        }
        .badge-lead {
            padding:3px 9px;
            border-radius:999px;
            font-size:11px;
            background:#1b2836;
            color:#4aa3ff;
        }
        .portfolio-grid {
            display:grid;
            grid-template-columns:repeat(auto-fit,minmax(120px,1fr));
            gap:10px;
            margin-top:10px;
            font-size:11px;
            color:#aaa;
        }
        .portfolio-item {
            border-radius:12px;
            border:1px dashed #444;
            padding:8px;
            text-align:center;
        }
    </style>
</head>
<body>
    <div class="topbar">
        <div class="brand">AURADECOR.ai · Contractor</div>
        <div class="user">You are logged in as <span style="color:#D4AF37;">Supplier / Contractor</span></div>
    </div>

    <div class="layout">
        <aside class="sidebar">
            <h2>Navigation</h2>
            <div class="nav-item active">Dashboard</div>
            <div class="nav-item">Incoming Projects</div>
            <div class="nav-item">Profile & Portfolio</div>
            <div class="nav-item">Subscription</div>
            <div class="nav-item">Account Settings</div>
        </aside>

        <main class="content">
            <h1 class="section-title">Get projects from AURADECOR owners</h1>
            <p class="section-sub">Complete your profile, upload your portfolio and start receiving design leads.</p>

            <div class="card-row">
                <div class="card">
                    <h3>Profile & resume</h3>
                    <p>Introduce your company so homeowners can quickly understand who you are and what you do.</p>
                    <form>
                        <div class="field">
                            <label>Company / Brand name</label>
                            <input type="text" placeholder="e.g. Golden Space Interiors">
                        </div>
                        <div class="field">
                            <label>Location</label>
                            <input type="text" placeholder="City, Country">
                        </div>
                        <div class="field">
                            <label>Specialization</label>
                            <select>
                                <option>Interior fit-out</option>
                                <option>Furniture supplier</option>
                                <option>Lighting & electrical</option>
                                <option>Full turnkey contractor</option>
                            </select>
                        </div>
                        <div class="field">
                            <label>WhatsApp number</label>
                            <input type="text" placeholder="+971 5x xxx xxxx">
                            <div class="hint">This number will be used to connect you directly with homeowners.</div>
                        </div>
                        <div class="field">
                            <label>Website / Instagram</label>
                            <input type="text" placeholder="https://yourwebsite.com or @yourinstagram">
                        </div>
                        <div class="field">
                            <label>Resume link (optional)</label>
                            <input type="text" placeholder="Link to your PDF resume on Drive / Dropbox">
                        </div>
                        <div class="field">
                            <label>Short bio</label>
                            <textarea placeholder="Describe your experience, style and what makes you unique."></textarea>
                        </div>
                        <button class="btn" type="button">Save profile (mock)</button>
                    </form>
                </div>

                <div class="card">
                    <h3>Portfolio / sample projects</h3>
                    <p>Upload a few of your best projects so homeowners can see your style and quality.</p>
                    <div class="field">
                        <label>Upload sample images</label>
                        <input type="file" multiple accept="image/*">
                        <div class="hint">You can upload multiple JPG/PNG images. In production, these will be stored in your portfolio.</div>
                    </div>
                    <div class="portfolio-grid">
                        <div class="portfolio-item">Sample project 1 (mock)</div>
                        <div class="portfolio-item">Sample project 2 (mock)</div>
                        <div class="portfolio-item">Sample project 3 (mock)</div>
                    </div>
                    <button class="btn" type="button" onclick="alert('Portfolio upload will be implemented later.')">
                        Save portfolio (mock)
                    </button>
                </div>
            </div>

            <div class="card">
                <h3>Latest design leads</h3>
                <p style="font-size:13px;color:#ddd;">Once your subscription is active, you’ll see real-time projects that match your profile here.</p>
                <div class="lead-list">
                    <div class="lead-item">
                        <strong>Dubai · 2BR Apartment</strong><br>
                        Modern living + kitchen design ready.
                        <span class="badge-lead">preview (mock)</span>
                    </div>
                    <div class="lead-item">
                        <strong>Tehran · Office lobby</strong><br>
                        Luxury reception area design ready.
                        <span class="badge-lead">preview (mock)</span>
                    </div>
                </div>
            </div>
        </main>
    </div>
</body>
</html>
    """)


# ------------------ صفحات احراز هویت (Login / Register) ------------------ #

@app.get("/login", response_class=HTMLResponse)
async def login_page():
    return HTMLResponse(content="""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Sign In | AURADECOR.ai</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        * { margin:0; padding:0; box-sizing:border-box; }
        body {
            font-family:'Inter',sans-serif;
            background:#050505;
            color:#fff;
            min-height:100vh;
            display:flex;
            align-items:center;
            justify-content:center;
        }
        .card {
            background:rgba(255,255,255,0.03);
            border:1px solid rgba(212,175,55,0.25);
            border-radius:24px;
            padding:40px 32px;
            width:100%;
            max-width:420px;
            box-shadow:0 20px 60px rgba(0,0,0,0.6);
        }
        h1 {
            font-size:24px;
            margin-bottom:8px;
            color:#D4AF37;
        }
        p.sub {
            font-size:14px;
            color:#aaa;
            margin-bottom:24px;
        }
        .field {
            margin-bottom:20px;
        }
        .field label {
            display:block;
            font-size:13px;
            margin-bottom:6px;
            color:#ddd;
        }
        .field input {
            width:100%;
            padding:12px 14px;
            border-radius:12px;
            border:1px solid rgba(212,175,55,0.3);
            background:rgba(0,0,0,0.6);
            color:#fff;
            font-size:14px;
        }
        .field input:focus {
            outline:none;
            border-color:#D4AF37;
            box-shadow:0 0 0 2px rgba(212,175,55,0.25);
        }
        .actions {
            margin-top:10px;
        }
        button {
            width:100%;
            padding:14px;
            border-radius:999px;
            border:none;
            background:linear-gradient(135deg,#D4AF37,#F1C40F);
            color:#000;
            font-weight:600;
            cursor:pointer;
            font-size:15px;
        }
        button:hover {
            box-shadow:0 16px 40px rgba(212,175,55,0.45);
            transform:translateY(-1px);
        }
        .link-row {
            margin-top:18px;
            font-size:13px;
            color:#bbb;
            text-align:center;
        }
        .link-row a {
            color:#D4AF37;
            text-decoration:none;
            font-weight:500;
        }
        .top-link {
            position:fixed;
            top:20px;
            left:30px;
            font-size:13px;
        }
        .top-link a {
            color:#D4AF37;
            text-decoration:none;
        }
    </style>
</head>
<body>
    <div class="top-link"><a href="/">← Back to Home</a></div>
    <div class="card">
        <h1>Welcome back</h1>
        <p class="sub">Sign in to manage your projects and designs.</p>

        <div style="margin-bottom: 18px;">
            <button type="button"
                    style="
                        width:100%;
                        padding:12px;
                        border-radius:999px;
                        border:1px solid rgba(212,175,55,0.4);
                        background:#111;
                        color:#fff;
                        font-weight:500;
                        font-size:14px;
                        display:flex;
                        align-items:center;
                        justify-content:center;
                        gap:8px;
                        cursor:pointer;
                    "
                    onclick="window.location.href='/auth/google'">
                <img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg"
                     alt="Google" style="width:18px;height:18px;">
                <span>Continue with Google</span>
            </button>
        </div>
        <div style="text-align:center;margin:12px 0 18px;color:#777;font-size:12px;">
            <span style="background:#050505;padding:0 8px;">or sign in with email</span>
            <hr style="border:none;border-top:1px solid #333;margin-top:-10px;">
        </div>

        <form action="/login" method="post">
            <div class="field">
                <label for="email">Email address</label>
                <input id="email" name="email" type="email" required placeholder="you@example.com">
            </div>
            <div class="field">
                <label for="password">Password</label>
                <input id="password" name="password" type="password" required placeholder="••••••••">
            </div>
            <div class="actions">
                <button type="submit">Sign In</button>
            </div>
        </form>
        <div class="link-row">
            New to AURADECOR.ai?
            <a href="/register">Create an account</a>
        </div>
    </div>
</body>
</html>
    """)


@app.get("/register", response_class=HTMLResponse)
async def register_page():
    return HTMLResponse(content="""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Get Started | AURADECOR.ai</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        * { margin:0; padding:0; box-sizing:border-box; }
        body {
            font-family:'Inter',sans-serif;
            background:#050505;
            color:#fff;
            min-height:100vh;
            display:flex;
            align-items:center;
            justify-content:center;
        }
        .card {
            background:rgba(255,255,255,0.03);
            border:1px solid rgba(212,175,55,0.25);
            border-radius:24px;
            padding:40px 32px;
            width:100%;
            max-width:480px;
            box-shadow:0 20px 60px rgba(0,0,0,0.6);
        }
        h1 {
            font-size:24px;
            margin-bottom:8px;
            color:#D4AF37;
        }
        p.sub {
            font-size:14px;
            color:#aaa;
            margin-bottom:24px;
        }
        .role-row {
            display:flex;
            gap:12px;
            margin-bottom:22px;
        }
        .role {
            flex:1;
            padding:14px 12px;
            border-radius:16px;
            border:1px solid rgba(212,175,55,0.35);
            background:rgba(0,0,0,0.7);
            text-align:left;
            cursor:pointer;
        }
        .role h3 {
            font-size:14px;
            margin-bottom:4px;
            color:#D4AF37;
        }
        .role p {
            font-size:12px;
            color:#aaa;
        }
        .field {
            margin-bottom:18px;
        }
        .field label {
            display:block;
            font-size:13px;
            margin-bottom:6px;
            color:#ddd;
        }
        .field input {
            width:100%;
            padding:12px 14px;
            border-radius:12px;
            border:1px solid rgba(212,175,55,0.3);
            background:rgba(0,0,0,0.6);
            color:#fff;
            font-size:14px;
        }
        .field input:focus {
            outline:none;
            border-color:#D4AF37;
            box-shadow:0 0 0 2px rgba(212,175,55,0.25);
        }
        button {
            width:100%;
            padding:14px;
            border-radius:999px;
            border:none;
            background:linear-gradient(135deg,#D4AF37,#F1C40F);
            color:#000;
            font-weight:600;
            cursor:pointer;
            font-size:15px;
        }
        button:hover {
            box-shadow:0 16px 40px rgba(212,175,55,0.45);
            transform:translateY(-1px);
        }
        .link-row {
            margin-top:18px;
            font-size:13px;
            color:#bbb;
            text-align:center;
        }
        .link-row a {
            color:#D4AF37;
            text-decoration:none;
            font-weight:500;
        }
        .top-link {
            position:fixed;
            top:20px;
            left:30px;
            font-size:13px;
        }
        .top-link a {
            color:#D4AF37;
            text-decoration:none;
        }
    </style>
</head>
<body>
    <div class="top-link"><a href="/">← Back to Home</a></div>
    <div class="card">
        <h1>Create your account</h1>
        <p class="sub">Choose your role and start using AURADECOR.ai in minutes.</p>

        <div style="margin-bottom: 18px;">
            <button type="button"
                    style="
                        width:100%;
                        padding:12px;
                        border-radius:999px;
                        border:1px solid rgba(212,175,55,0.4);
                        background:#111;
                        color:#fff;
                        font-weight:500;
                        font-size:14px;
                        display:flex;
                        align-items:center;
                        justify-content:center;
                        gap:8px;
                        cursor:pointer;
                    "
                    onclick="window.location.href='/auth/google'">
                <img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg"
                     alt="Google" style="width:18px;height:18px;">
                <span>Continue with Google</span>
            </button>
        </div>
        <div style="text-align:center;margin:12px 0 18px;color:#777;font-size:12px;">
            <span style="background:#050505;padding:0 8px;">or sign up with email</span>
            <hr style="border:none;border-top:1px solid #333;margin-top:-10px;">
        </div>

        <form action="/register" method="post">
            <div class="role-row">
                <label class="role">
                    <input type="radio" name="role" value="owner" required style="margin-right:6px;">
                    <h3>Homeowner</h3>
                    <p>Upload floor plans and get AI-generated interiors.</p>
                </label>
                <label class="role">
                    <input type="radio" name="role" value="contractor" required style="margin-right:6px;">
                    <h3>Contractor</h3>
                    <p>Receive projects and connect with clients.</p>
                </label>
            </div>
            <div class="field">
                <label for="email">Email address</label>
                <input id="email" name="email" type="email" required placeholder="you@example.com">
            </div>
            <div class="field">
                <label for="password">Password</label>
                <input id="password" name="password" type="password" required placeholder="••••••••">
            </div>
            <button type="submit">Get Started</button>
        </form>
        <div class="link-row">
            Already have an account?
            <a href="/login">Sign in</a>
        </div>
    </div>
</body>
</html>
    """)


@app.get("/auth/google", response_class=HTMLResponse)
async def auth_google_mock():
    return HTMLResponse(
        "<h2 style='font-family:Arial;color:#D4AF37;text-align:center;margin-top:80px;'>"
        "Google OAuth will be implemented here soon 🚀</h2>"
    )


# ------------------ صفحات پروژه‌های Owner ------------------ #

@app.get("/owner/projects", response_class=HTMLResponse)
async def owner_projects():
    return HTMLResponse(content="""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>My Projects | AURADECOR.ai</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        * { margin:0; padding:0; box-sizing:border-box; }
        body {
            font-family:'Inter',sans-serif;
            background:#050505;
            color:#fff;
            min-height:100vh;
        }
        .topbar {
            display:flex;
            align-items:center;
            justify-content:space-between;
            padding:16px 32px;
            border-bottom:1px solid #333;
            background:rgba(5,5,5,0.96);
            position:sticky;
            top:0;
            z-index:10;
        }
        .brand { font-weight:600; color:#D4AF37; }
        .layout {
            display:grid;
            grid-template-columns:260px 1fr;
            min-height:100vh;
        }
        .sidebar {
            border-right:1px solid #222;
            padding:24px 18px;
            background:#070707;
        }
        .sidebar h2 {
            font-size:14px;
            color:#777;
            margin-bottom:16px;
        }
        .nav-item {
            padding:10px 12px;
            border-radius:10px;
            font-size:14px;
            color:#ccc;
            cursor:pointer;
            margin-bottom:6px;
        }
        .nav-item.active {
            background:linear-gradient(135deg,#D4AF37,#F1C40F);
            color:#000;
            font-weight:600;
        }
        .nav-item:hover {
            background:rgba(255,255,255,0.05);
        }
        .content {
            padding:28px 32px 40px;
        }
        .section-title {
            font-size:22px;
            margin-bottom:8px;
        }
        .section-sub {
            font-size:14px;
            color:#aaa;
            margin-bottom:24px;
        }
        .projects-table {
            width:100%;
            border-collapse:collapse;
            font-size:13px;
        }
        .projects-table th, .projects-table td {
            padding:10px 8px;
            border-bottom:1px solid #222;
            text-align:left;
        }
        .projects-table th {
            color:#bbb;
            font-weight:500;
        }
        .badge {
            padding:3px 9px;
            border-radius:999px;
            font-size:11px;
        }
        .badge-processing {
            background:#333;
            color:#F1C40F;
        }
        .badge-ready {
            background:#16361a;
            color:#2ecc71;
        }
        .new-btn {
            display:inline-block;
            padding:9px 18px;
            border-radius:999px;
            border:none;
            background:linear-gradient(135deg,#D4AF37,#F1C40F);
            color:#000;
            font-weight:600;
            font-size:13px;
            text-decoration:none;
        }
        .new-btn:hover {
            box-shadow:0 10px 26px rgba(212,175,55,0.4);
            transform:translateY(-1px);
        }
    </style>
</head>
<body>
    <div class="topbar">
        <div class="brand">AURADECOR.ai · Owner</div>
        <a href="/register/owner" style="color:#D4AF37;font-size:13px;text-decoration:none;">Back to dashboard</a>
    </div>

    <div class="layout">
        <aside class="sidebar">
            <h2>Navigation</h2>
            <a href="/register/owner" style="text-decoration:none;">
                <div class="nav-item">Dashboard</div>
            </a>
            <div class="nav-item active">My Projects</div>
            <div class="nav-item">Downloads</div>
            <div class="nav-item">Subscription</div>
            <div class="nav-item">Account Settings</div>
        </aside>

        <main class="content">
            <h1 class="section-title">My Projects</h1>
            <p class="section-sub">All floor plans you have uploaded and the designs generated by AURADECOR.ai.</p>

            <div style="margin-bottom:18px;">
                <a href="/owner/projects/new" class="new-btn">+ New Project</a>
            </div>

            <table class="projects-table">
                <thead>
                    <tr>
                        <th>Project name</th>
                        <th>Type</th>
                        <th>Style</th>
                        <th>Status</th>
                        <th>Last update</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Modern Apartment · Living + Kitchen</td>
                        <td>Residential</td>
                        <td>Modern</td>
                        <td><span class="badge badge-processing">processing (mock)</span></td>
                        <td>Today · 12:30</td>
                    </tr>
                    <tr>
                        <td>Luxury Villa · Master Bedroom</td>
                        <td>Residential</td>
                        <td>Luxury</td>
                        <td><span class="badge badge-ready">ready (mock)</span></td>
                        <td>Yesterday · 19:05</td>
                    </tr>
                </tbody>
            </table>
        </main>
    </div>
</body>
</html>
    """)


@app.get("/owner/projects/new", response_class=HTMLResponse)
async def owner_new_project():
    return HTMLResponse(content="""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>New Project | AURADECOR.ai</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        * { margin:0; padding:0; box-sizing:border-box; }
        body {
            font-family:'Inter',sans-serif;
            background:#050505;
            color:#fff;
            min-height:100vh;
        }
        .topbar {
            display:flex;
            align-items:center;
            justify-content:space-between;
            padding:16px 32px;
            border-bottom:1px solid #333;
            background:rgba(5,5,5,0.96);
            position:sticky;
            top:0;
            z-index:10;
        }
        .brand { font-weight:600; color:#D4AF37; }
        .container {
            max-width:900px;
            margin:0 auto;
            padding:28px 20px 40px;
        }
        .section-title {
            font-size:22px;
            margin-bottom:8px;
        }
        .section-sub {
            font-size:14px;
            color:#aaa;
            margin-bottom:24px;
        }
        .card {
            background:rgba(255,255,255,0.03);
            border-radius:20px;
            border:1px solid rgba(212,175,55,0.20);
            padding:24px 20px;
        }
        .field {
            margin-bottom:16px;
        }
        .field label {
            display:block;
            font-size:13px;
            margin-bottom:6px;
            color:#ddd;
        }
        .field input, .field select, .field textarea {
            width:100%;
            padding:10px 12px;
            border-radius:12px;
            border:1px solid #444;
            background:#000;
            color:#fff;
            font-size:13px;
        }
        .field textarea {
            min-height:70px;
            resize:vertical;
        }
        .upload-box {
            border:1px dashed rgba(212,175,55,0.6);
            border-radius:16px;
            padding:18px;
            background:rgba(0,0,0,0.5);
            text-align:center;
        }
        .upload-box p {
            font-size:13px;
            color:#ccc;
            margin-bottom:8px;
        }
        .btn {
            display:inline-block;
            padding:11px 22px;
            border-radius:999px;
            border:none;
            background:linear-gradient(135deg,#D4AF37,#F1C40F);
            color:#000;
            font-weight:600;
            font-size:14px;
            cursor:pointer;
            margin-top:14px;
        }
        .btn:hover {
            box-shadow:0 12px 30px rgba(212,175,55,0.4);
            transform:translateY(-1px);
        }
        .hint {
            font-size:11px;
            color:#777;
            margin-top:4px;
        }
    </style>
</head>
<body>
    <div class="topbar">
        <div class="brand">AURADECOR.ai · Owner</div>
        <a href="/owner/projects" style="color:#D4AF37;font-size:13px;text-decoration:none;">Back to My Projects</a>
    </div>

    <div class="container">
        <h1 class="section-title">Create a new project</h1>
        <p class="section-sub">Upload a floor plan, choose the space type and style, and let AURADECOR.ai generate designs.</p>

        <div class="card">
            <form>
                <div class="field">
                    <label>Project name</label>
                    <input type="text" placeholder="e.g. Modern apartment - living + kitchen">
                </div>
                <div class="field">
                    <label>Project type</label>
                    <select>
                        <option>Residential</option>
                        <option>Office</option>
                        <option>Retail</option>
                        <option>Hospitality</option>
                    </select>
                </div>
                <div class="field">
                    <label>Preferred style</label>
                    <select>
                        <option>Modern</option>
                        <option>Luxury</option>
                        <option>Minimal</option>
                        <option>Classic</option>
                        <option>Industrial</option>
                    </select>
                </div>
                <div class="field">
                    <label>Floor plan file</label>
                    <div class="upload-box">
                        <p>Drop your floor plan image/PDF here, or click to choose.</p>
                        <input type="file" accept="image/*,.pdf">
                        <div class="hint">Supported formats: JPG, PNG, PDF. Max 25MB (mock for now).</div>
                    </div>
                </div>
                <div class="field">
                    <label>Notes for designer (optional)</label>
                    <textarea placeholder="Any specific requirements, colors, furniture brands, etc."></textarea>
                </div>
                <button class="btn" type="button" onclick="alert('Project creation will be implemented with database in the next step.')">
                    Create project (mock)
                </button>
            </form>
        </div>
    </div>
</body>
</html>
    """)


# ------------------ پردازش فرم‌ها (ساده / Mock) ------------------ #

@app.post("/login")
async def login_submit(
    email: str = Form(...),
    password: str = Form(...)
):
    html = (
        "<h2 style='color:#D4AF37;"
        "font-family:Arial;"
        "text-align:center;"
        "margin-top:80px;'>"
        f"Logged in as {email} (mock)</h2>"
    )
    return HTMLResponse(html)


@app.post("/register")
async def register_submit(
    role: str = Form(...),
    email: str = Form(...),
    password: str = Form(...)
):
    if role == "owner":
        redirect_url = "/register/owner"
    else:
        redirect_url = "/register/contractor"

    html = (
        "<h2 style='color:#D4AF37;"
        "font-family:Arial;"
        "text-align:center;"
        "margin-top:80px;'>"
        f"Registered as {role}. Next: "
        f"<a href='{redirect_url}'>continue</a></h2>"
    )
    return HTMLResponse(html)
# ------------------ مغز AURADECOR - تحلیل پلان ------------------ #

@app.post("/api/plan/analyze", response_model=FloorplanAnalysis)
async def analyze_plan(file: UploadFile = File(...)):
    """تحلیل هوشمند پلان - فعلاً Mock، بعداً مدل واقعی"""
    
    # شبیه‌سازی تحلیل واقعی پلان (بعداً با Gemini Vision جایگزین می‌شود)
    analysis = FloorplanAnalysis(
        project_id="proj_001",
        total_area_m2=145.5,
        rooms=[
            Room(id="living_1", type="living_room", name="Main Living Room", area_m2=42.3),
            Room(id="kitchen_1", type="kitchen", name="Open Kitchen", area_m2=28.1),
            Room(id="bedroom_1", type="bedroom", name="Master Bedroom", area_m2=35.2),
            Room(id="bathroom_1", type="bathroom", name="Master Bathroom", area_m2=12.4),
            Room(id="balcony_1", type="balcony", name="Balcony", area_m2=9.5)
        ],
        connections=[
            ("living_1", "kitchen_1"),
            ("living_1", "balcony_1"),
            ("bedroom_1", "bathroom_1")
        ]
    )
    return analysis


# ------------------ مغز AURADECOR - تولید طراحی ------------------ #

@app.post("/api/design/generate", response_model=ProjectDesign)
async def generate_design(
    plan: FloorplanAnalysis = Body(...),
    style: str = Body(..., embed=True),
    budget: Optional[float] = Body(5000, embed=True)
):
    """تولید طراحی حرفه‌ای بر اساس تحلیل پلان + سلیقه کاربر"""
    
    rooms_design = []
    for room in plan.rooms:
        room_design = RoomDesign(
            room_id=room.id,
            style=style,
            description=f"""
            Professional {style} design for {room.name}:
            • Open layout with natural light emphasis
            • Premium materials: { 'marble/oak' if style=='luxury' else 'concrete/wood' }
            • Smart furniture placement for optimal flow
            • Color palette: { 'gold/neutral' if style=='luxury' else 'white/grey' }
            """.strip(),
            materials=["Oak flooring", "Matte walls", "LED lighting"],
            furniture=[
                "Sofa L-Shape" if room.type=="living_room" else "King Bed",
                "Dining Table" if room.type=="kitchen" else "Vanity",
                "Smart TV Unit"
            ],
            image_urls=[
                f"https://auradecor.ai/mock/{style}/{room.type}-1.jpg",
                f"https://auradecor.ai/mock/{style}/{room.type}-2.jpg"
            ]
        )
        rooms_design.append(room_design)
    
    return ProjectDesign(
        project_id=plan.project_id,
        style=style,
        total_cost_estimate=min(budget * 1.2, 25000),
        rooms=rooms_design,
        notes=f"AI-generated {style} design ready for review. All images are 4K photorealistic renders."
    )


# ------------------ مغز AURADECOR - ویرایش چت ------------------ #

@app.post("/api/design/edit")
async def edit_design(
    project_id: str = Body(...),
    current_design: ProjectDesign = Body(...),
    user_message: str = Body(...)
):
    """ویرایش طراحی با دستورات متنی کاربر"""
    
    # شبیه‌سازی چت - بعداً با Gemini Chat جایگزین می‌شود
    edits = {
        "changes_made": [
            f"✅ Applied: '{user_message}'",
            "✅ Adjusted furniture layout",
            "✅ Updated color scheme",
            "✅ Optimized lighting positions"
        ],
        "new_images": [
            "https://auradecor.ai/mock/edited-1.jpg",
            "https://auradecor.ai/mock/edited-2.jpg"
        ]
    }
    return edits


if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000, reload=True)
