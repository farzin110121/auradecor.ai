from pydantic import BaseModel
from typing import List

class Room(BaseModel):
    name: str
    area: float

class FloorplanAnalysis(BaseModel):
    rooms: List[Room]

class Design(BaseModel):
    id: str
    title: str
    imageUrl: str
    materials: List[dict]
    prompt: str
