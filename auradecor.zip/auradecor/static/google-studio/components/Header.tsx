
import React from 'react';

interface HeaderProps {
  onReset: () => void;
}

const Header: React.FC<HeaderProps> = ({ onReset }) => {
  return (
    <header className="bg-white shadow-sm sticky top-0 z-10">
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        <div className="flex items-center space-x-3">
            <div className="bg-gray-800 text-white font-bold text-xl rounded-md p-2 w-10 h-10 flex items-center justify-center">
                P
            </div>
            <h1 className="text-xl font-bold text-gray-800 tracking-tight">
            PEYTAM <span className="font-light text-gray-500">AI Design Studio</span>
            </h1>
        </div>
        <button
          onClick={onReset}
          className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 border border-gray-200 rounded-md hover:bg-gray-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-800 transition-colors"
        >
          New Project
        </button>
      </div>
    </header>
  );
};

export default Header;
