
import React, { useState, useCallback } from 'react';
import { Room, Design, MaterialBreakdownItem, ChatMessage, SupplierRequest } from '../types';
import { generateDesignAids, generateImage, refineImage, generateSupplierPackage, getDesignAdvice } from '../services/geminiService';
import { fileToBase64 } from '../utils/fileUtils';
import Loader from './Loader';
import SparklesIcon from './icons/SparklesIcon';
import ChevronLeftIcon from './icons/ChevronLeftIcon';

interface DesignStudioProps {
  room: Room;
  onBack: () => void;
}

const DESIGN_STYLES = [
  "Modern Minimalist",
  "Scandinavian",
  "Bohemian",
  "Industrial",
  "Coastal",
  "Farmhouse",
  "Mid-Century Modern",
  "Art Deco",
  "Luxury"
];

type Tab = 'design' | 'materials' | 'album' | 'chat';

const DesignStudio: React.FC<DesignStudioProps> = ({ room, onBack }) => {
  const [designs, setDesigns] = useState<Design[]>([]);
  const [currentDesignIndex, setCurrentDesignIndex] = useState<number | null>(null);
  const [stylePrompt, setStylePrompt] = useState<string>('');
  const [refinementPrompt, setRefinementPrompt] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [loadingMessage, setLoadingMessage] = useState<string>('');
  const [error, setError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<Tab>('design');

  const [chatInput, setChatInput] = useState('');
  const [chatHistory, setChatHistory] = useState<ChatMessage[]>([]);
  const [isChatLoading, setIsChatLoading] = useState(false);
  const [showSupplierModal, setShowSupplierModal] = useState(false);
  const [supplierPackage, setSupplierPackage] = useState<SupplierRequest | null>(null);


  const currentDesign = currentDesignIndex !== null ? designs[currentDesignIndex] : null;

  const handleGenerate = useCallback(async (isRefinement = false, chatRefinement: string | null = null) => {
    const promptToUse = chatRefinement || (isRefinement ? refinementPrompt : stylePrompt);
    if (!promptToUse) return;
    
    // Use main loader for generation triggered from chat
    const setLoading = chatRefinement ? setIsLoading : setIsLoading;
    const setMessage = chatRefinement ? setLoadingMessage : setLoadingMessage;
    
    setLoading(true);
    setError(null);
    setMessage(isRefinement || chatRefinement ? 'Refining your design...' : 'Generating design concepts...');

    try {
        const designAids = await generateDesignAids(room, stylePrompt, chatRefinement || (isRefinement ? refinementPrompt : null));
        
        setMessage('Rendering photorealistic image...');

        let imageBase64;
        if((isRefinement || chatRefinement) && currentDesign) {
             const response = await fetch(currentDesign.imageUrl);
             const blob = await response.blob();
             const previousImageBase64 = await fileToBase64(new File([blob], "previous.png", {type: "image/png"}));
             imageBase64 = await refineImage(designAids.imagePrompt, previousImageBase64);
        } else {
             imageBase64 = await generateImage(designAids.imagePrompt);
        }

        const newDesign: Design = {
            id: `v${designs.length + 1}`,
            title: designAids.albumTitle || `Version ${designs.length + 1}`,
            imageUrl: `data:image/png;base64,${imageBase64}`,
            materials: designAids.materialBreakdown,
            prompt: designAids.imagePrompt,
        };
        
        setDesigns(prev => [...prev, newDesign]);
        setCurrentDesignIndex(designs.length);
        setRefinementPrompt('');

        if (chatRefinement) {
            setActiveTab('design'); // Switch to the design tab to show the new result
        }

    } catch (err) {
        console.error(err);
        setError(err instanceof Error ? err.message : 'An unknown error occurred.');
    } finally {
        setLoading(false);
    }
  }, [room, stylePrompt, refinementPrompt, designs, currentDesign]);

  const handleChatSubmit = async () => {
    const userInput = chatInput.trim();
    if(!userInput) return;

    if (!currentDesign) {
        setChatHistory(prev => [...prev, { sender: 'user', text: userInput }, { sender: 'ai', text: "Please generate a design first, then you can ask me to refine it!" }]);
        setChatInput('');
        return;
    }

    const newUserMessage: ChatMessage = { sender: 'user', text: userInput };
    setChatHistory(prev => [...prev, newUserMessage]);
    setChatInput('');
    setIsChatLoading(true);

    try {
        // 1. Get conversational advice
        const geminiHistory = [...chatHistory, newUserMessage].map(msg => ({
            role: msg.sender === 'user' ? 'user' : 'model',
            parts: [{ text: msg.text }]
        }));
        const aiAdvice = await getDesignAdvice(geminiHistory);
        setChatHistory(prev => [...prev, { sender: 'ai', text: aiAdvice }]);
        
        // 2. Trigger the actual design refinement
        await handleGenerate(true, userInput);

    } catch (err) {
       setChatHistory(prev => [...prev, { sender: 'ai', text: "Sorry, I'm having trouble connecting right now." }]);
    } finally {
        setIsChatLoading(false);
    }
  };

  const handleRequestQuotes = async () => {
      if(!currentDesign) return;
      setIsLoading(true);
      setLoadingMessage("Preparing supplier package...")
      try {
          const pkg = await generateSupplierPackage(room.name, currentDesign.materials);
          setSupplierPackage(pkg);
          setShowSupplierModal(true);
// Fix: Add curly braces to the catch block to fix syntax error.
      } catch (err) {
          setError(err instanceof Error ? err.message : 'Could not generate package.');
      } finally {
          setIsLoading(false);
      }
  };

  return (
    <div>
        <button onClick={onBack} className="flex items-center text-sm text-gray-600 hover:text-gray-900 mb-6">
            <ChevronLeftIcon className="w-5 h-5 mr-1" />
            Back to Room Selection
        </button>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 bg-white rounded-xl shadow-md p-4 flex items-center justify-center min-h-[60vh]">
                {isLoading ? (
                    <Loader message={loadingMessage} />
                ) : currentDesign ? (
                    <img src={currentDesign.imageUrl} alt={currentDesign.title} className="max-w-full max-h-[80vh] rounded-lg object-contain" />
                ) : (
                    <div className="text-center text-gray-500">
                        <h3 className="text-xl font-semibold">Your design will appear here.</h3>
                        <p>Describe the style you want in the panel to the right to get started.</p>
                    </div>
                )}
            </div>

            <div className="bg-white rounded-xl shadow-md p-6 flex flex-col">
                <div className="flex-shrink-0">
                    <h2 className="text-2xl font-bold capitalize">{room.name.replace('_', ' ')} Design Studio</h2>
                    <div className="border-b border-gray-200 mt-4">
                        <nav className="-mb-px flex space-x-6">
                           {(['design', 'materials', 'album', 'chat'] as Tab[]).map(tab => (
                               <button key={tab} onClick={() => setActiveTab(tab)} className={`capitalize py-3 px-1 border-b-2 font-medium text-sm transition-colors ${activeTab === tab ? 'border-gray-800 text-gray-900' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'}`}>
                                   {tab}
                                   {tab === 'album' && <span className="ml-2 bg-gray-200 text-gray-700 text-xs font-bold px-2 py-0.5 rounded-full">{designs.length}</span>}
                                </button>
                           ))}
                        </nav>
                    </div>
                </div>

                <div className="flex-grow overflow-y-auto mt-6">
                    {error && <div className="mb-4 p-3 bg-red-100 text-red-800 rounded-md text-sm">{error}</div>}
                    
                    {activeTab === 'design' && (
                        <div>
                             {!currentDesign ? (
                                <>
                                <label htmlFor="style-select" className="block text-sm font-medium text-gray-700">Select Design Style</label>
                                <select
                                  id="style-select"
                                  value={stylePrompt}
                                  onChange={e => setStylePrompt(e.target.value)}
                                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-gray-800 focus:ring-gray-800 sm:text-sm"
                                >
                                  <option value="" disabled>Choose a style...</option>
                                  {DESIGN_STYLES.map(style => (
                                    <option key={style} value={style}>{style}</option>
                                  ))}
                                </select>
                                
                                <button onClick={() => handleGenerate(false)} disabled={!stylePrompt || isLoading} className="mt-6 w-full inline-flex items-center justify-center px-4 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-gray-800 hover:bg-gray-900 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-800 disabled:bg-gray-400 disabled:cursor-not-allowed">
                                    <SparklesIcon className="w-5 h-5 mr-2" />
                                    Generate Design
                                </button>
                                </>
                             ) : (
                                <>
                                <label htmlFor="refinement" className="block text-sm font-medium text-gray-700">Refine Your Design</label>
                                <textarea id="refinement" rows={4} value={refinementPrompt} onChange={e => setRefinementPrompt(e.target.value)} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-gray-800 focus:ring-gray-800 sm:text-sm" placeholder="e.g., change the floor to dark wood, add brass fittings"></textarea>
                                
                                <button onClick={() => handleGenerate(true)} disabled={!refinementPrompt || isLoading} className="mt-6 w-full inline-flex items-center justify-center px-4 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-gray-800 hover:bg-gray-900 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-800 disabled:bg-gray-400 disabled:cursor-not-allowed">
                                    <SparklesIcon className="w-5 h-5 mr-2" />
                                    Refine
                                </button>
                                <button onClick={() => { setCurrentDesignIndex(null); setStylePrompt(''); }} className="mt-2 w-full text-center text-sm text-gray-600 hover:underline">Start a new design concept</button>
                                </>
                             )}
                        </div>
                    )}

                    {activeTab === 'materials' && (
                        <div>
                            {!currentDesign ? <p className="text-gray-500 text-sm">Generate a design to see its material breakdown.</p> : (
                                <>
                                <h3 className="font-semibold mb-3 text-gray-800">Material Breakdown for "{currentDesign.title}"</h3>
                                <ul className="space-y-2">
                                    {currentDesign.materials.map((item, index) => (
                                        <li key={index} className="flex justify-between p-2 bg-gray-50 rounded-md text-sm">
                                            <span className="font-medium text-gray-700 capitalize">{item.name}</span>
                                            <span className="text-gray-600">{item.description}</span>
                                        </li>
                                    ))}
                                </ul>
                                <button onClick={handleRequestQuotes} className="mt-6 w-full text-sm font-medium text-gray-700 bg-gray-100 hover:bg-gray-200 py-2 rounded-md">
                                    Request Quotes
                                </button>
                                </>
                            )}
                        </div>
                    )}

                     {activeTab === 'album' && (
                        <div className="grid grid-cols-2 gap-4">
                            {!designs.length ? <p className="text-gray-500 text-sm col-span-2">Your generated designs will appear here.</p> : designs.map((design, index) => (
                                <button key={design.id} onClick={() => setCurrentDesignIndex(index)} className={`rounded-lg overflow-hidden relative block group focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-800 ${currentDesignIndex === index ? 'ring-2 ring-gray-800' : ''}`}>
                                    <img src={design.imageUrl} alt={design.title} className="w-full h-24 object-cover" />
                                    <div className="absolute inset-0 bg-black bg-opacity-40 flex items-end p-2">
                                        <p className="text-white text-xs font-bold">{design.title}</p>
                                    </div>
                                </button>
                            ))}
                        </div>
                     )}

                    {activeTab === 'chat' && (
                        <div className="flex flex-col h-full">
                           <div className="flex-grow space-y-4 overflow-y-auto pr-2">
                            {chatHistory.length === 0 && <p className="text-gray-500 text-sm">Generate a design, then ask me to refine it! e.g., "Make the walls a lighter shade of blue."</p>}
                               {chatHistory.map((msg, i) => (
                                   <div key={i} className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                                       <p className={`max-w-xs lg:max-w-sm px-4 py-2 rounded-lg text-sm ${msg.sender === 'user' ? 'bg-gray-800 text-white' : 'bg-gray-100 text-gray-800'}`}>{msg.text}</p>
                                   </div>
                               ))}
                               {isChatLoading && <div className="flex justify-start"><p className="px-4 py-2 rounded-lg text-sm bg-gray-100 text-gray-500 italic">Thinking...</p></div>}
                           </div>
                           <div className="mt-4 flex-shrink-0">
                               <div className="flex space-x-2">
                                   <input type="text" value={chatInput} onChange={e => setChatInput(e.target.value)} onKeyPress={e => e.key === 'Enter' && handleChatSubmit()} placeholder="Ask AI to refine the design..." className="flex-grow block w-full rounded-md border-gray-300 shadow-sm focus:border-gray-800 focus:ring-gray-800 sm:text-sm"/>
                                   <button onClick={handleChatSubmit} disabled={isChatLoading || isLoading} className="px-4 py-2 bg-gray-800 text-white rounded-md text-sm font-medium hover:bg-gray-900 disabled:bg-gray-400">Send</button>
                               </div>
                           </div>
                        </div>
                    )}
                </div>
            </div>
        </div>
        
        {showSupplierModal && supplierPackage && (
            <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-20" onClick={() => setShowSupplierModal(false)}>
                <div className="bg-white rounded-lg shadow-xl p-8 max-w-lg w-full" onClick={e => e.stopPropagation()}>
                    <h3 className="text-xl font-bold mb-4">Supplier Request Package</h3>
                    <p className="text-sm text-gray-600 mb-4">You can copy this package and send it to your suppliers for quotes.</p>
                    <pre className="bg-gray-100 p-4 rounded-md text-sm overflow-x-auto">
                        {JSON.stringify(supplierPackage, null, 2)}
                    </pre>
                    <button onClick={() => setShowSupplierModal(false)} className="mt-6 w-full bg-gray-800 text-white py-2 rounded-md hover:bg-gray-900">Close</button>
                </div>
            </div>
        )}
    </div>
  );
};

export default DesignStudio;