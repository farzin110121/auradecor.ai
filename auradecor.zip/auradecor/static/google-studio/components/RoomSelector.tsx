
import React from 'react';
import { Room } from '../types';

interface RoomSelectorProps {
  rooms: Room[];
  onSelectRoom: (room: Room) => void;
  onReset: () => void;
}

const RoomSelector: React.FC<RoomSelectorProps> = ({ rooms, onSelectRoom, onReset }) => {
  return (
    <div className="max-w-4xl mx-auto">
      <div className="text-center mb-10">
        <h2 className="text-3xl font-bold text-gray-900 mb-2">Analysis Complete</h2>
        <p className="text-lg text-gray-600">We've identified the following rooms. Select one to start designing.</p>
      </div>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {rooms.map((room) => (
          <button
            key={room.name}
            onClick={() => onSelectRoom(room)}
            className="p-6 bg-white rounded-xl shadow-md hover:shadow-lg hover:-translate-y-1 transform transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-800 text-left"
          >
            <h3 className="text-xl font-bold text-gray-800 capitalize">{room.name.replace('_', ' ')}</h3>
            <p className="text-gray-500 mt-1">Size: {room.size}</p>
             <p className="text-gray-500 mt-1">Entry: {room.entry} wall</p>
             {room.equipment && room.equipment.length > 0 && (
                <div className="mt-4 pt-2 border-t border-gray-200">
                    <h4 className="text-sm font-semibold text-gray-600">Detected Items:</h4>
                    <ul className="text-sm text-gray-500 list-disc list-inside">
                        {room.equipment.map((item, index) => (
                            <li key={index} className="capitalize">{item.name}</li>
                        ))}
                    </ul>
                </div>
            )}
          </button>
        ))}
      </div>
      <div className="text-center mt-12">
        <button
          onClick={onReset}
          className="text-sm text-gray-600 hover:text-gray-900 underline"
        >
          Or upload a different floorplan
        </button>
      </div>
    </div>
  );
};

export default RoomSelector;
