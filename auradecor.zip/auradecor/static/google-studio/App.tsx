
import React, { useState, useCallback, useEffect } from 'react';
import { AppState, Room, FloorplanAnalysis } from './types';
import { analyzeFloorplan } from './services/geminiService';
import { fileToBase64 } from './utils/fileUtils';
import Header from './components/Header';
import FileUpload from './components/FileUpload';
import RoomSelector from './components/RoomSelector';
import DesignStudio from './components/DesignStudio';
import Loader from './components/Loader';

const App: React.FC = () => {
  const [appState, setAppState] = useState<AppState>(AppState.UPLOAD);
  const [analysisResult, setAnalysisResult] = useState<FloorplanAnalysis | null>(null);
  const [selectedRoom, setSelectedRoom] = useState<Room | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleFileUpload = useCallback(async (file: File) => {
    setIsLoading(true);
    setError(null);
    try {
      const base64Image = await fileToBase64(file);
      const result = await analyzeFloorplan(base64Image);
      setAnalysisResult(result);
      setAppState(AppState.SELECT_ROOM);
    } catch (err) {
      console.error(err);
      setError('Failed to analyze floorplan. Please check the image or try again.');
      setAppState(AppState.UPLOAD);
    } finally {
      setIsLoading(false);
    }
  }, []);

  const handleRoomSelect = useCallback((room: Room) => {
    setSelectedRoom(room);
    setAppState(AppState.DESIGN);
  }, []);

  const handleBackToRoomSelect = useCallback(() => {
    setSelectedRoom(null);
    setAppState(AppState.SELECT_ROOM);
  }, []);

  const handleReset = useCallback(() => {
    setAppState(AppState.UPLOAD);
    setAnalysisResult(null);
    setSelectedRoom(null);
    setError(null);
    setIsLoading(false);
  }, []);

  const renderContent = () => {
    if (isLoading) {
        let message = "Loading...";
        if (appState === AppState.UPLOAD) message = "Analyzing your floorplan...";
        return <Loader message={message} />;
    }

    switch (appState) {
      case AppState.UPLOAD:
        return <FileUpload onFileUpload={handleFileUpload} error={error} />;
      case AppState.SELECT_ROOM:
        if (analysisResult) {
          return <RoomSelector rooms={analysisResult.rooms} onSelectRoom={handleRoomSelect} onReset={handleReset} />;
        }
        handleReset();
        return null;
      case AppState.DESIGN:
        if (selectedRoom) {
          return <DesignStudio room={selectedRoom} onBack={handleBackToRoomSelect} />;
        }
        handleBackToRoomSelect();
        return null;
      default:
        return <FileUpload onFileUpload={handleFileUpload} error={error} />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 font-sans">
      <Header onReset={handleReset} />
      <main className="container mx-auto px-4 py-8">
        {renderContent()}
      </main>
    </div>
  );
};

export default App;
