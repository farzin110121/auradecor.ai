
import { GoogleGenAI, GenerateContentResponse, Type, Chat } from '@google/genai';
import { FloorplanAnalysis, Room, MaterialBreakdownItem, SupplierRequest } from '../types';

const getAiClient = () => {
    // NOTE: This will be populated by the environment. Do not edit.
    const API_KEY = process.env.API_KEY;

    if (!API_KEY) {
        // This should be caught by the ApiKeySelector flow, but as a fallback.
        throw new Error("API_KEY environment variable not set.");
    }

    return new GoogleGenAI({ apiKey: API_KEY });
};

const cleanJsonString = (jsonString: string): string => {
  return jsonString.replace(/^```json\s*|```\s*$/g, '').trim();
};

export const analyzeFloorplan = async (base64Image: string): Promise<FloorplanAnalysis> => {
    const ai = getAiClient();
    const systemInstruction = `You are an expert architectural analyst. Analyze the provided floorplan image and identify all rooms (kitchen, living_room, bedroom, etc.).
    For each room, provide its name, approximate size in meters, a description of its four walls (N, S, E, W) noting features like windows or doors, the direction of its main entry, and a list of any fixed equipment (like sinks or beds) with their locations.
    Return ONLY a single, valid JSON object based on this structure:
    {
      "rooms": [
        {
          "name": "room_name",
          "size": "WxLm",
          "walls": [{"N":"..."},{"S":"..."},{"E":"..."},{"W":"..."}],
          "entry": "N/S/E/W",
          "equipment": [{"name": "item", "location": "..."}]
        }
      ]
    }
    No other text or explanations.`;

    const response: GenerateContentResponse = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: {
            parts: [
                { inlineData: { mimeType: 'image/jpeg', data: base64Image } },
                { text: systemInstruction }
            ]
        },
        config: {
            responseMimeType: 'application/json',
        },
    });

    try {
        const rawText = response.text || '';
        const jsonStr = cleanJsonString(rawText);
        const parsed = JSON.parse(jsonStr);
        return parsed as FloorplanAnalysis;
    } catch (e) {
        console.error("Failed to parse floorplan analysis response:", response.text, e);
        throw new Error("Could not understand the floorplan structure.");
    }
};

interface DesignGenerationResult {
    imagePrompt: string;
    materialBreakdown: MaterialBreakdownItem[];
    albumTitle: string;
}

export const generateDesignAids = async (room: Room, style: string, refinementPrompt: string | null = null): Promise<DesignGenerationResult> => {
    const ai = getAiClient();
    
    const userRequestBlock = refinementPrompt
        ? `
This is a refinement of a previous design.
- Base Style: ${style}
- User's Requested Change: "${refinementPrompt}"

Your generated 'imagePrompt' must describe the room in the base style, but with the user's requested change fully integrated. The 'albumTitle' should reflect this change (e.g., "${style} with ${refinementPrompt}").
`
        : `
User Request:
- Style: ${style}
`;

    const systemInstruction = `You are a precise interior designer AI. Your task is to generate a JSON object for a room design based on strict data.

    Your output MUST adhere to these rules:
    - The design must not alter the room's architecture (walls, windows, doors).
    - The location of existing equipment is fixed and must be preserved.
    - The camera view for the render must be from the entry door, looking into the room at a 45-degree angle.

    Based on the user's request and the provided room data, generate a JSON object containing:
    1. 'imagePrompt': A detailed, photorealistic prompt for an image generator that respects all rules.
    2. 'materialBreakdown': An array of objects, each with a 'name' and 'description' (including metric quantities).
    3. 'albumTitle': A short, descriptive title for the design.
    
    ${userRequestBlock}

    Room Data:
    - Name: ${room.name}
    - Size: ${room.size}
    - Entry Door: ${room.entry} wall
    - Walls: ${JSON.stringify(room.walls)}
    - Equipment Layout: ${JSON.stringify(room.equipment)}

    Output ONLY the single valid JSON object.`;

    const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: systemInstruction,
        config: {
            responseMimeType: 'application/json',
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    imagePrompt: { type: Type.STRING },
                    materialBreakdown: {
                        type: Type.ARRAY,
                        items: {
                            type: Type.OBJECT,
                            properties: {
                                name: { type: Type.STRING },
                                description: { type: Type.STRING }
                            },
                            required: ['name', 'description']
                        }
                    },
                    albumTitle: {
                        type: Type.STRING
                    }
                }
            }
        }
    });

    try {
        const jsonStr = cleanJsonString(response.text || '{}');
        return JSON.parse(jsonStr) as DesignGenerationResult;
    } catch(e) {
        console.error("Failed to parse design aids response:", response.text, e);
        throw new Error("Could not generate design details.");
    }
};

export const generateImage = async (prompt: string): Promise<string> => {
    const ai = getAiClient();
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash-image',
        contents: { parts: [{ text: prompt }] },
        config: {
            imageConfig: {
                aspectRatio: '16:9',
            }
        },
    });

    for (const part of response.candidates?.[0]?.content?.parts || []) {
        if (part.inlineData) {
            return part.inlineData.data;
        }
    }
    throw new Error("No image was generated.");
};

export const refineImage = async (prompt: string, base64Image: string): Promise<string> => {
    const ai = getAiClient();
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash-image',
        contents: {
            parts: [
                { inlineData: { data: base64Image, mimeType: 'image/png' } },
                { text: prompt },
            ],
        },
    });

    for (const part of response.candidates?.[0]?.content?.parts || []) {
        if (part.inlineData) {
            return part.inlineData.data;
        }
    }
    throw new Error("No refined image was generated.");
}

export const generateSupplierPackage = async (roomName: string, materials: MaterialBreakdownItem[]): Promise<SupplierRequest> => {
    const ai = getAiClient();
    const systemInstruction = `You are a procurement assistant AI. Convert the following material list for a ${roomName} into a JSON object with "room" and "materials" keys.
    Materials: ${JSON.stringify(materials)}
    Output ONLY the single, valid JSON object.`;

    const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: systemInstruction,
        config: {
            responseMimeType: 'application/json',
        },
    });
    
    try {
        const rawText = response.text || '';
        const jsonStr = cleanJsonString(rawText);
        return JSON.parse(jsonStr) as SupplierRequest;
    } catch(e) {
        console.error("Failed to parse supplier package response:", response.text, e);
        throw new Error("Could not generate supplier package.");
    }
};


export const getDesignAdvice = async (chatHistory: { role: string, parts: { text: string }[] }[]): Promise<string> => {
    const ai = getAiClient();
    
    const history = chatHistory.slice(0, -1);
    const lastMessage = chatHistory[chatHistory.length - 1].parts[0].text;

    const chat: Chat = ai.chats.create({
        model: 'gemini-3-flash-preview',
        history: history,
        config: {
            systemInstruction: "You are a helpful and creative interior design assistant. Provide concise, actionable advice to help users with their room designs."
        }
    });

    const response = await chat.sendMessage({ message: lastMessage });
    
    return response.text || "I'm not sure how to answer that. Could you rephrase?";
}
