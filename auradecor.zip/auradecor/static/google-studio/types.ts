
export enum AppState {
  UPLOAD = 'UPLOAD',
  SELECT_ROOM = 'SELECT_ROOM',
  DESIGN = 'DESIGN',
}

export interface Wall {
  [direction: string]: string; // e.g., "N": "window+sink"
}

export interface Equipment {
    name: string; // e.g., "sink", "bed", "sofa"
    location: string; // e.g., "Against N wall", "Center of room"
}

export interface Room {
  name: string;
  size: string; // e.g., "4x3m"
  walls: Wall[];
  entry: string; // e.g., "W"
  equipment: Equipment[];
}

export interface FloorplanAnalysis {
  rooms: Room[];
}

export interface Material {
  [materialName: string]: string; // e.g., "floor": "grey_tile"
}

export interface MaterialBreakdownItem {
    name: string;
    description: string;
}

export interface Design {
  id: string;
  title: string;
  imageUrl: string;
  materials: MaterialBreakdownItem[];
  prompt: string;
}

export interface SupplierRequest {
    room: string;
    materials: { [key: string]: string }[];
}

export interface ChatMessage {
    sender: 'user' | 'ai';
    text: string;
}
